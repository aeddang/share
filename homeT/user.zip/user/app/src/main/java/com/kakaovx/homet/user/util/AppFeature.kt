package com.kakaovx.homet.user.util

object AppFeature {

    const val APP_REMOTE_DEBUG = true
    const val APP_MEMORY_DEBUG = true
    const val APP_LOG_DEBUG = true
}