package com.kakaovx.homet.user.component.ui.skeleton.injecter

interface Injectable {
    fun inject(){}
    fun onSubscribe(){}
}