package com.kakaovx.homet.user.constant

enum class LoadingType {
    MORE, REFRESH, NONE
}