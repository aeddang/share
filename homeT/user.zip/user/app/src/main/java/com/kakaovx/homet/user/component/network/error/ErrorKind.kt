package com.kakaovx.homet.user.component.network.error

enum class ErrorKind {
    NETWORK,
    HTTP,
    UNEXPECTED
}