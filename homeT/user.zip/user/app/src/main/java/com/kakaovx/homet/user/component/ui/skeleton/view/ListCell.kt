package com.kakaovx.homet.user.component.ui.skeleton.view

import android.content.Context
import com.kakaovx.homet.user.component.ui.skeleton.injecter.InjectableFrameLayout

abstract class ListCell(context:Context): InjectableFrameLayout (context)