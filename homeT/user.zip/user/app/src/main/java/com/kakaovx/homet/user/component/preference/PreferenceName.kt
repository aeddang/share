package com.kakaovx.homet.user.component.preference

class PreferenceName {
    companion object {
        const val SETTING: String = "pref_setting"
    }
}